import React from 'react';
import { Link } from 'react-router-dom';
import './AboutUs.css';
import Background from '../components/Background';
import Header from '../components/Header';
import home from "../assets/home.png";


const AboutUs = () => {
  return (
    <div className="about-page">
      <Background />

<Header 
  showAboutUs={false} 
  extraRightContent={
    <Link to="/">
      <img src={home} alt="Home" className="home-img" />
    </Link>
  } 
/>


<main className="about-content">
      <div className="about-summary">
        <h1 className="about-title">About Us</h1>

        <p>
          Welcome to <strong>KASIT-Agenda</strong>, the innovative platform designed to streamline 
          event management at <strong>King Abdullah II School of Information Technology</strong>. 
          Our mission is to simplify the process of discovering, organizing, and managing campus 
          events—bringing students, faculty, and staff closer together through clear, accessible 
          communication.
        </p>
        
        <p>
          With a user-friendly interface and dynamic features, KASIT-Agenda is your go-to 
          solution for all things events.
        </p>
      </div>
    </main>
    </div>
  );
};

export default AboutUs;