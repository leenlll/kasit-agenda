import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { db } from "../firebaseConfig"; // ✅ No auth needed
import { collection, query, where, getDocs, addDoc } from "firebase/firestore";
import "./EventInfo.css";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";

const EventInfoPage = () => {
  const { date } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState([]);
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(5);
  const [userName, setUserName] = useState(""); // ✅ Allow users to enter a name

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        console.log(`🔍 Fetching event details for date: ${date}`);

        // ✅ Query Firestore to find the event by its date
        const eventsCollection = collection(db, "events");
        const q = query(eventsCollection, where("date", "==", date));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          setEvent(querySnapshot.docs[0].data());
        } else {
          setEvent(null);
        }
      } catch (error) {
        console.error("❌ Error fetching event:", error);
      } finally {
        setLoading(false);
      }
    };

    const fetchFeedback = async () => {
      try {
        console.log(`🔍 Fetching feedback for event on: ${date}`);

        const feedbackCollection = collection(db, "eventFeedback");
        const feedbackQuery = query(feedbackCollection, where("eventDate", "==", date));
        const feedbackSnapshot = await getDocs(feedbackQuery);

        const feedbackList = feedbackSnapshot.docs.map((doc) => doc.data());
        setFeedback(feedbackList);
        console.log("✅ Retrieved feedback:", feedbackList);
      } catch (error) {
        console.error("❌ Error fetching feedback:", error);
      }
    };

    fetchEvent();
    fetchFeedback();
  }, [date]);

  const handleFeedbackSubmit = async () => {
    try {
      if (!comment.trim()) {
        alert("⚠️ Feedback cannot be empty.");
        return;
      }

      const newFeedback = {
        eventDate: date,
        comment,
        rating,
        user: userName || "Anonymous", // ✅ If no name is provided, use "Anonymous"
      };

      await addDoc(collection(db, "eventFeedback"), newFeedback);
      setFeedback([...feedback, newFeedback]); // Update UI
      setComment(""); // Clear input
      setUserName(""); // Clear name input
      setRating(5); // Reset rating
      console.log("✅ Feedback submitted:", newFeedback);
    } catch (error) {
      console.error("❌ Error submitting feedback:", error);
    }
  };

  return (
    <div className="event-page">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <Link to="/">
            <img src={home} alt="Home" className="home-img" />
          </Link>
        }
      />

      <main className="event-content">
        <motion.h1
          className="event-title"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          Event Details
        </motion.h1>

        {loading ? (
          <p>Loading event details...</p>
        ) : event ? (
          <motion.div
            className="event-box"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p><strong>Event Name:</strong> {event.eventName}</p>
            <p><strong>Description:</strong> {event.description}</p>
            <p><strong>Time:</strong> {event.timeSlot}</p>
            <p><strong>Place:</strong> {event.place.join(", ")}</p>
            <p><strong>Guests:</strong> {event.guests || "None"}</p>
            
            {/* Feedback Form */}
            <h2>Leave Feedback</h2>
            <input
              type="text"
              className="name-input"
              placeholder="Enter your name (optional)"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
            />
            <select value={rating} onChange={(e) => setRating(e.target.value)}>
              {[1, 2, 3, 4, 5].map((num) => (
                <option key={num} value={num}>{num} Stars</option>
              ))}
            </select>
            <textarea
              className="feedback-box"
              placeholder="Leave your feedback here..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
            <button className="feedback-submit" onClick={handleFeedbackSubmit}>
              Submit Feedback
            </button>

            {/* Display Feedback */}
            <h2>Event Feedback</h2>
            {feedback.length > 0 ? (
              feedback.map((fb, index) => (
                <div key={index} className="feedback-item">
                  <p><strong>{fb.user}:</strong> {fb.comment} ⭐ {fb.rating}</p>
                </div>
              ))
            ) : (
              <p>No feedback yet. Be the first to leave a review!</p>
            )}
          </motion.div>
        ) : (
          <motion.p className="no-event" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
            No event found for this date.
          </motion.p>
        )}
      </main>
    </div>
  );
};

export default EventInfoPage;
