import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./BookingPage.css";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";
import viewRequestsIcon from "../assets/view-requests.png";
import { db } from "../firebaseConfig"; 
import { collection, addDoc, getDocs } from "firebase/firestore"; 
import { useEffect } from "react";
import { auth } from "../firebaseConfig";


const BookingPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const selectedDate = new URLSearchParams(location.search).get("date");

  const [formData, setFormData] = useState({
    eventName: "",
    description: "",
    timeSlot: "",
    place: [],
    targetedStudents: "",
    guests: "",
    resources: "",
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        place: checked
          ? [...prev.place, value]
          : prev.place.filter((item) => item !== value),
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!formData.eventName || !formData.description || !formData.timeSlot) {
      toast.error("Please fill in all required fields.");
      return;
    }
  
    try {
      const user = auth.currentUser; // ✅ Get the logged-in organizer
      if (!user) {
        toast.error("⚠️ Please sign in first!");
        return;
      }
  
      const bookingData = {
        ...formData,
        date: selectedDate,
        organizerId: user.uid, // ✅ Save the organizer's UID
        status: "Pending",
      };
  
      console.log("📤 Saving booking:", bookingData);
  
      const docRef = await addDoc(collection(db, "bookings"), bookingData);
      console.log("✅ Booking saved with ID:", docRef.id);
  
      toast.success("Booking submitted successfully!");
      setTimeout(() => navigate("/view-requests"), 2000);
    } catch (error) {
      console.error("❌ Firestore Error:", error);
      toast.error("⚠️ Failed to submit booking. Please try again.");
    }
  };  


const [bookings, setBookings] = useState([]); // ✅ Store bookings

useEffect(() => {
  const fetchBookings = async () => {
    try {
      console.log("🔍 Fetching bookings from Firestore...");

      const querySnapshot = await getDocs(collection(db, "bookings"));
      const bookingsList = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      console.log("✅ Retrieved bookings:", bookingsList);
      setBookings(bookingsList);
    } catch (error) {
      console.error("❌ Error fetching bookings:", error);
    }
  };

  fetchBookings();
}, []);


  return (
    <div className="booking-page">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <div className="header-icons">
            <Link to="/view-requests">
              <img src={viewRequestsIcon} alt="View Requests" className="requests-img" />
            </Link>
            <Link to="/">
              <img src={home} alt="Home" className="home-img" />
            </Link>
          </div>
        }
      /> <div className="booking-form">
      <motion.div
        className="booking-container"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="booking-title">Booking Dashboard</h1>
        <p className="selected-date">Booking for: <strong>{selectedDate || "No Date Selected"}</strong></p>

        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <label>Event Name:</label>
          <input type="text" name="eventName" onChange={handleChange} required />

          <label>Description:</label>
          <textarea name="description" onChange={handleChange} required />

          <label>Time Slot:</label>
          <div className="time-options">
            {["10:00-12:00", "12:00-2:00", "2:00-4:00"].map((slot) => (
              <label key={slot}>
                <input type="radio" name="timeSlot" value={slot} onChange={handleChange} required />
                {slot}
              </label>
            ))}
          </div>

          <label>Place:</label>
          <div className="place-options">
            {["Al-Louzy", "GF"].map((place) => (
              <label key={place}>
                <input type="checkbox" name="place" value={place} onChange={handleChange} />
                {place}
              </label>
            ))}
          </div>

          <div className="button-group">
            <button type="button" className="action-button" onClick={() => navigate(-1)}>
              Go Back
            </button>
            <button type="submit" className="action-button">
              Submit
            </button>
          </div>
        </motion.form>
        
      </motion.div>
      </div>
    </div>
  );
};

export default BookingPage;
