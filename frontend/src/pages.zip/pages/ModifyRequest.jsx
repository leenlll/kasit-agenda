import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { doc, getDoc, updateDoc } from "firebase/firestore"; // ✅ Firestore functions
import { db } from "../firebaseConfig"; // ✅ Firestore instance
import "./ModifyRequest.css";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";

const ModifyRequest = () => {
  const { id: bookingId } = useParams(); // ✅ Get booking ID from URL
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        console.log(`🔍 Fetching booking from Firestore: ${bookingId}`);

        if (!bookingId) {
          console.error("❌ Booking ID is missing from URL!");
          setLoading(false);
          return;
        }

        const eventRef = doc(db, "bookings", bookingId); // ✅ Fetch from "bookings" collection
        const eventSnap = await getDoc(eventRef);

        if (eventSnap.exists()) {
          console.log("✅ Booking found:", eventSnap.data());
          setEvent({ id: eventSnap.id, ...eventSnap.data() });
        } else {
          console.error("❌ Booking not found in Firestore!");
          setEvent(null);
        }
      } catch (error) {
        console.error("❌ Error fetching booking:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [bookingId]);

  // ✅ Handle input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setEvent((prev) => ({
        ...prev,
        place: checked
          ? [...prev.place, value]
          : prev.place.filter((item) => item !== value),
      }));
    } else {
      setEvent((prev) => ({ ...prev, [name]: value }));
    }
  };

  // ✅ Handle form submission (update Firestore)
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      console.log("📤 Updating Firestore with:", event);
      const eventRef = doc(db, "bookings", event.id); // ✅ Update "bookings"

      await updateDoc(eventRef, {
        eventName: event.eventName,
        date: event.date,
        description: event.description,
        place: event.place,
        timeSlot: event.timeSlot,
      });

      alert("✅ Booking updated successfully!");
      navigate("/view-requests"); // ✅ Redirect back after updating
    } catch (error) {
      console.error("❌ Error updating booking:", error);
      alert("⚠️ Failed to update booking. Please try again.");
    }
  };

  if (loading) return <h1>Loading...</h1>;
  if (!event) return <h1>❌ Booking Not Found</h1>;

  return (
    <div className="modify-request-page">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <Link to="/">
            <img src={home} alt="Home" className="home-img" />
          </Link>
        }
      />

      <motion.div
        className="modify-container"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="modify-title">Modify Booking Details</h1>

        <form onSubmit={handleSubmit}>
          <label>Event Name:</label>
          <input type="text" name="eventName" value={event.eventName} onChange={handleChange} required />

          <label>Date:</label>
          <input type="date" name="date" value={event.date} onChange={handleChange} required />

          <label>Description:</label>
          <textarea name="description" value={event.description} onChange={handleChange} required />

          <label>Place:</label>
          <div className="place-options">
            {["Al-Louzy", "GF"].map((place) => (
              <label key={place}>
                <input
                  type="checkbox"
                  name="place"
                  value={place}
                  checked={event.place.includes(place)}
                  onChange={handleChange}
                />
                {place}
              </label>
            ))}
          </div>

          <label>Time Slot:</label>
          <input type="text" name="timeSlot" value={event.timeSlot} onChange={handleChange} required />

          <div className="button-group">
            <Link to="/view-requests" className="back-button">Back</Link>
            <button type="submit" className="submit-button">Submit</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default ModifyRequest;
