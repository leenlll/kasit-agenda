import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import Calendar from "react-calendar";
import { motion } from "framer-motion";
import "./AvailableBookings.css";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";
import viewRequestsIcon from "../assets/view-requests.png";

const AvailableBookings = () => {
  const [availableDates, setAvailableDates] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setAvailableDates([1, 3, 7, 12]);
  }, []);

  const tileClassName = ({ date }) => {
    return availableDates.includes(date.getDate()) ? "available-day" : "";
  };

  const handleDateClick = (date) => {
    const formattedDate = date.toISOString().split("T")[0];
    console.log("Navigating to booking:", formattedDate);
    navigate(`/booking?date=${formattedDate}`);
  };

  return (
    <div className="available-bookings">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <div className="header-icons">
            <Link to="/view-requests">
              <img src={viewRequestsIcon} alt="View Requests" className="requests-img" />
            </Link>
            <Link to="/">
              <img src={home} alt="Home" className="home-img" />
            </Link>
          </div>
        }
      />

      <main className="bookings-content">
        <div className="all-container">
        <motion.h1
          className="bookings-title"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          Available Booking Days
        </motion.h1>

        <motion.div
          className="calendar-container"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Calendar 
            tileClassName={tileClassName}
            onClickDay={handleDateClick} 
          />
        </motion.div>
        </div>
      </main>
    </div>
  );
};

export default AvailableBookings;
