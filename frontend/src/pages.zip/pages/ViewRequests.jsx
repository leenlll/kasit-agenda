import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { collection, getDocs, deleteDoc, doc, updateDoc, query, where } from "firebase/firestore";
import { db, auth } from "../firebaseConfig"; // ✅ Ensure correct imports
import "./ViewRequests.css";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";

const ViewRequests = () => {
  const [requests, setRequests] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        console.log("🔍 Fetching event requests...");

        const user = auth.currentUser; // ✅ Get logged-in organizer
        if (!user) {
          console.error("❌ No logged-in user!");
          return;
        }

        // ✅ Fetch from bookings (Pending & Denied)
        const bookingsQuery = query(collection(db, "bookings"), where("organizerId", "==", user.uid));
        const bookingsSnapshot = await getDocs(bookingsQuery);
        const bookingsList = bookingsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // ✅ Fetch from events (Approved)
        const eventsQuery = query(collection(db, "events"), where("organizerId", "==", user.uid));
        const eventsSnapshot = await getDocs(eventsQuery);
        const eventsList = eventsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // ✅ Combine lists
        const allRequests = [...bookingsList, ...eventsList];
        console.log("✅ Organizer's Requests:", allRequests);
        setRequests(allRequests);
      } catch (error) {
        console.error("❌ Error fetching event requests:", error);
      }
    };

    fetchRequests();
  }, []);

  // ✅ Function to Cancel Booking (Delete from Firestore)
  const handleCancelBooking = async (eventId) => {
    try {
      const confirmDelete = window.confirm("Are you sure you want to cancel this booking?");
      if (!confirmDelete) return;

      await deleteDoc(doc(db, "bookings", eventId)); // ✅ Remove from `bookings`
      setRequests(requests.filter((event) => event.id !== eventId));
      console.log(`✅ Booking canceled: ${eventId}`);
    } catch (error) {
      console.error("❌ Error canceling booking:", error);
    }
  };

  return (
    <div className="view-requests-page">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <Link to="/">
            <img src={home} alt="Home" className="home-img" />
          </Link>
        }
      />

      <main className="requests-content">
        <h1 className="requests-title">Your Event Requests</h1>

        <table className="requests-table">
          <thead>
            <tr>
              <th>Event Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {requests.length > 0 ? (
              requests.map((event) => (
                <tr key={event.id}>
                  <td>{event.eventName}</td>
                  <td>{event.date}</td>
                  <td className={`status-${event.status.toLowerCase()}`}>{event.status}</td>
                  <td>
                    {event.status === "Pending" ? (
                      <>
                        <button className="modify-btn" onClick={() => navigate(`/modify-request/${event.id}`)}>
                          Modify
                        </button>
                        <button className="cancel-btn" onClick={() => handleCancelBooking(event.id)}>
                          Cancel
                        </button>
                      </>
                    ) : event.status === "Denied" ? (
                      <>
                        <button className="modify-btn" onClick={() => navigate(`/modify-request/${event.id}`)}>
                          Resubmit
                        </button>
                      </>
                    ) : (
                      <span className="status-info">Finalized</span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No event requests found</td>
              </tr>
            )}
          </tbody>
        </table>

        <Link to="/available-bookings" className="back-button">Back</Link>
      </main>
    </div>
  );
};

export default ViewRequests;
