import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { db } from "../firebaseConfig";
import { collection, getDocs, updateDoc, doc } from "firebase/firestore";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const [events, setEvents] = useState([]);

  // ✅ Fetch all event requests (Pending, Approved, Denied)
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        console.log("🔍 Fetching all event requests...");

        // ✅ Fetch from `bookings` (Pending & Denied)
        const bookingsSnapshot = await getDocs(collection(db, "bookings"));
        const bookingsList = bookingsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // ✅ Fetch from `events` (Approved)
        const eventsSnapshot = await getDocs(collection(db, "events"));
        const eventsList = eventsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // ✅ Combine both lists so Admin sees all requests
        const allRequests = [...bookingsList, ...eventsList];
        console.log("✅ Fetched event requests:", allRequests);
        setEvents(allRequests);
      } catch (error) {
        console.error("❌ Error fetching events:", error);
      }
    };

    fetchEvents();
  }, []);

  // ✅ Handle event approval or denial
  const handleStatusUpdate = async (eventId, newStatus) => {
    try {
      const eventRef = doc(db, "bookings", eventId);

      // ✅ If Approved, update status but keep in bookings
      if (newStatus === "Approved" || newStatus === "Denied") {
        await updateDoc(eventRef, { status: newStatus });
      }

      // ✅ Update UI state
      setEvents(events.map((event) => (event.id === eventId ? { ...event, status: newStatus } : event)));
      console.log(`✅ Event ${newStatus}:`, eventId);
    } catch (error) {
      console.error(`❌ Error updating event status to ${newStatus}:`, error);
    }
  };

  return (
    <div className="admin-page">
      <Background />
      <Header
        showAboutUs={false}
        extraRightContent={
          <Link to="/">
            <img src={home} alt="Home" className="home-img" />
          </Link>
        }
      />

      <main className="admin-content">
        <motion.h1
          className="admin-title"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          Admin Dashboard
        </motion.h1>

        <div className="requests-content">
          <table className="requests-table">
            <thead>
              <tr>
                <th>Event Name</th>
                <th>Date</th>
                <th>Description</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {events.length > 0 ? (
                events.map((event) => (
                  <tr key={event.id}>
                    <td>{event.eventName}</td>
                    <td>{event.date}</td>
                    <td>{event.description}</td>
                    <td className={`status-${event.status.toLowerCase()}`}>{event.status}</td>
                    <td>
                      {event.status === "Pending" ? (
                        <>
                          <button
                            className="modify-btn"
                            onClick={() => handleStatusUpdate(event.id, "Approved")}
                          >
                            Approve
                          </button>
                          <button
                            className="modify-btn deny-btn"
                            onClick={() => handleStatusUpdate(event.id, "Denied")}
                          >
                            Deny
                          </button>
                        </>
                      ) : (
                        <span className="status-info">{event.status}</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5">No event requests found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
