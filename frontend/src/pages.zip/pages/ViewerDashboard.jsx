import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "./ViewerDashboard.css";
import { db } from "../firebaseConfig";
import { collection, getDocs } from "firebase/firestore";
import Background from "../components/Background";
import Header from "../components/Header";
import home from "../assets/home.png";

const ViewerDashboard = () => {
  const [date, setDate] = useState(new Date());
  const [events, setEvents] = useState({});
  const navigate = useNavigate();

  // ✅ Fetch approved events from Firestore
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        console.log("🔍 Fetching approved events...");
        const eventsCollection = collection(db, "events"); // ✅ Get only `Approved` events
        const querySnapshot = await getDocs(eventsCollection);
        const eventList = {};

        querySnapshot.docs.forEach((doc) => {
          const eventData = doc.data();
          if (eventData.status === "Approved") {
            const eventDate = eventData.date; // Ensure `date` is stored as "YYYY-MM-DD"
            eventList[eventDate] = {
              name: eventData.eventName,
              description: eventData.description,
            };
          }
        });

        setEvents(eventList);
        console.log("✅ Approved Events Fetched:", eventList);
      } catch (error) {
        console.error("❌ Error fetching approved events:", error);
      }
    };

    fetchEvents();
  }, []);

  // ✅ Handle clicking on a date with an event
  const handleDateClick = (value) => {
    const formattedDate = value.toISOString().split("T")[0];
    if (events[formattedDate]) {
      navigate(`/EventInfo/${formattedDate}`);
    }
  };

  return (
    <div className="viewer-page">
      <Background />

      <Header
        showAboutUs={false}
        extraRightContent={
          <Link to="/">
            <img src={home} alt="Home" className="home-img" />
          </Link>
        }
      />

      <main className="viewer-content">
        <motion.h1
          className="viewer-title"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          Viewer Dashboard
        </motion.h1>

        <motion.div
          className="calendar-container"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Calendar
            onChange={setDate}
            value={date}
            onClickDay={handleDateClick} // ✅ Navigate when clicking an event date
            tileContent={({ date }) => {
              const formattedDate = date.toISOString().split("T")[0];
              return events[formattedDate] ? (
                <div className="event-marker">📍</div>
              ) : null;
            }}
          />
        </motion.div>
      </main>
    </div>
  );
};

export default ViewerDashboard;
